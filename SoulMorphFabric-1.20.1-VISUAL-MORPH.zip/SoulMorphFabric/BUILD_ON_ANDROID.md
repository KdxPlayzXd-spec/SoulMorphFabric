# Build Soul Morph on Android with GitHub Actions

This project includes `.github/workflows/build.yml`. GitHub Actions builds it using Java 17 and Gradle 8.7, then uploads the JAR as an artifact.

## One-time setup
1. Create a GitHub account and a new repository named `SoulMorphFabric`.
2. On Android, install Termux from F-Droid (recommended source: https://f-droid.org/packages/com.termux/).
3. Download and extract this ZIP into your Android storage, for example `Download/SoulMorphFabric`.
4. In Termux, allow storage access and install Git:

   ```sh
   termux-setup-storage
   pkg update
   pkg install git
   ```

5. Change into the extracted project folder. The exact path depends on where you extracted it. For example:

   ```sh
   cd ~/storage/downloads/SoulMorphFabric
   ```

6. Configure Git (use your own name and email):

   ```sh
   git config --global user.name "Your Name"
   git config --global user.email "you@example.com"
   ```

7. Connect the GitHub repository and push the source. Replace `YOUR_USERNAME` with your GitHub username:

   ```sh
   git init
   git add .
   git commit -m "Add Soul Morph Fabric mod source"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/SoulMorphFabric.git
   git push -u origin main
   ```

   GitHub may ask you to authenticate. Use the browser/device sign-in flow or a Personal Access Token; your GitHub account password is not accepted for Git over HTTPS.

## Download the built mod
1. Open your repository on GitHub.
2. Tap **Actions** and open **Build Soul Morph Fabric Mod**.
3. Wait for the workflow to finish with a green check mark.
4. Open the successful run and scroll to **Artifacts**.
5. Download `soul-morph-fabric-1.20.1` and extract it. The `.jar` inside `build/libs` is the mod file.

To rebuild after changes, commit and push them to the `main` branch. You can also run the workflow manually from Actions using **Run workflow**.

## Notes
- This workflow compiles the source; it does not guarantee the mod is bug-free or that every feature is complete.
- The source README lists known limitations. This update adds third-person mob-model rendering, but it still needs a successful build and in-game test.
- Install the resulting JAR on the Fabric 1.20.1 client and/or dedicated server as appropriate. Back up worlds before testing.


## Build verification note

The GitHub Actions workflow installs Gradle 8.7 and uses Java 17. The project
does not require a checked-in Gradle wrapper for that workflow. If building
locally in Termux, run `gradle build` from this directory with a compatible
Gradle 8.7 installation.

## Visual morph update (1.2.0)

The client now receives active morph selections for all online players and attempts to render the selected vanilla mob model in third-person. First-person hands and the player's collision/hitbox remain unchanged. Test on a copy of your world first.
