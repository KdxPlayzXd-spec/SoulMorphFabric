# Soul Morph — Fabric 1.20.1

A Fabric mod source project for Minecraft 1.20.1. Requires Java 17, Fabric Loader and Fabric API.

## Current implementation

- Gives players a Morph Wand when they join or respawn and restores it if it is missing during the server tick.
- Right-clicking the wand opens a menu of captured mob souls.
- The server validates soul selections and saves active morphs in the world's persistent data.
- **Third-person visual morphing:** client-side rendering replaces a player's third-person player model with the vanilla renderer/model for the selected captured mob. Other clients receive the active morph state from the server.
- Morph ability effects currently implemented: blaze (fire resistance), dolphin (water breathing and dolphin's grace), rabbit/slime/magma cube (jump boost), spider/cave spider (night vision), enderman (speed), zombie/husk/drowned (strength), phantom (slow falling), and turtle (resistance).
- Morph activation plays a vanilla beacon sound and emits soul particles.
- Existing three-life PvP, ban, soul shard and revival code is retained.

## Important limitations

This is an **in-progress source project, not a verified release build**. The new visual renderer has not yet been compiled or tested in Minecraft in this environment. It is intended to change the player's model in third-person views; first-person hands remain the normal player hands. Morphing changes appearance only: it does not change the player's hitbox, collision size, inventory, movement physics, or mob AI. Large mobs may visually overlap nearby blocks or players because the player keeps the normal player hitbox.

Some mobs may need additional rendering adjustments or special handling. The ability list is limited to the effects listed above. Back up worlds before testing.

## Build

Run from this project directory with JDK 17 and Gradle 8.7:

```bash
gradle build --no-daemon
```

The resulting mod JAR should appear under `build/libs/`. The GitHub Actions workflow in `.github/workflows/build.yml` performs this build and uploads the JAR artifacts.

## Compatibility

- Minecraft 1.20.1
- Fabric Loader 0.15.x or compatible
- Fabric API 0.92.2+1.20.1
- Java 17
