package com.kdxplayz.soulmorph.client;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Client-side mirror of the server's active morph selections. */
public final class ClientMorphs {
    private static final Map<UUID, String> ACTIVE = new ConcurrentHashMap<>();

    private ClientMorphs() {}

    public static void set(UUID playerId, String morphId) {
        if (morphId == null || morphId.isEmpty()) {
            ACTIVE.remove(playerId);
        } else {
            ACTIVE.put(playerId, morphId);
        }
    }

    public static String get(UUID playerId) {
        return ACTIVE.getOrDefault(playerId, "");
    }

    public static void clear() {
        ACTIVE.clear();
    }
}
