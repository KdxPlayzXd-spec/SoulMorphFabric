package com.kdxplayz.soulmorph.client;

import com.kdxplayz.soulmorph.MorphNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

public class MorphMenuScreen extends Screen {
    private final List<String> souls;
    private final String active;
    private int scroll;
    public MorphMenuScreen(List<String> souls, String active) {
        super(Text.literal("Soul Morph - Captured Souls"));
        this.souls = new ArrayList<>(souls);
        this.active = active;
    }
    @Override protected void init() { rebuildButtons(); }
    private void rebuildButtons() {
        clearChildren();
        int left = width / 2 - 105;
        addDrawableChild(ButtonWidget.builder(Text.literal("Remove morph"), b -> choose("none"))
                .dimensions(left, height - 42, 210, 20).build());
        int visible = Math.max(1, (height - 100) / 24);
        int start = Math.min(scroll, Math.max(0, souls.size() - visible));
        for (int i = start; i < Math.min(souls.size(), start + visible); i++) {
            String id = souls.get(i);
            String label = id.replace("minecraft:", "").replace('_', ' ');
            if (id.equals(active)) label = "✓ " + label + " (active)";
            addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> choose(id))
                    .dimensions(left, 42 + (i - start) * 24, 210, 20).build());
        }
        if (souls.size() > visible) {
            addDrawableChild(ButtonWidget.builder(Text.literal("▲"), b -> { scroll = Math.max(0, scroll - 1); rebuildButtons(); })
                    .dimensions(left - 25, 42, 20, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("▼"), b -> { scroll = Math.min(souls.size() - visible, scroll + 1); rebuildButtons(); })
                    .dimensions(left + 215, 42, 20, 20).build());
        }
    }
    private void choose(String id) {
        var buf = net.fabricmc.fabric.api.networking.v1.PacketByteBufs.create();
        buf.writeString(id);
        ClientPlayNetworking.send(MorphNetworking.SELECT_MORPH, buf);
        close();
    }
    @Override public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 18, 0xA8EFFF);
        if (souls.isEmpty()) context.drawCenteredTextWithShadow(textRenderer, "No captured souls yet. Defeat mobs to collect souls!", width / 2, height / 2 - 8, 0xFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }
    @Override public boolean shouldPause() { return false; }
}
