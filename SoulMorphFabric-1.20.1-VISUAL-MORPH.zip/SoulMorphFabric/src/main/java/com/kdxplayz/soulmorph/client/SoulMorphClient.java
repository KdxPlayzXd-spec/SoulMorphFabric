package com.kdxplayz.soulmorph.client;

import com.kdxplayz.soulmorph.MorphNetworking;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;

public class SoulMorphClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(
            MorphNetworking.MORPH_LIST,
            (client, handler, buf, responseSender) -> {
                var souls = buf.readCollection(
                    ArrayList::new, b -> b.readString(128)
                );
                String active = buf.readString(128);
                client.execute(() -> MinecraftClient.getInstance().setScreen(
                    new MorphMenuScreen(souls, active)
                ));
            }
        );

        ClientPlayNetworking.registerGlobalReceiver(
            MorphNetworking.SYNC_MORPH,
            (client, handler, buf, responseSender) -> {
                var playerId = buf.readUuid();
                String morphId = buf.readString(128);
                client.execute(() -> ClientMorphs.set(playerId, morphId));
            }
        );

        ClientPlayConnectionEvents.DISCONNECT.register(
            (handler, client) -> ClientMorphs.clear()
        );
    }
}
