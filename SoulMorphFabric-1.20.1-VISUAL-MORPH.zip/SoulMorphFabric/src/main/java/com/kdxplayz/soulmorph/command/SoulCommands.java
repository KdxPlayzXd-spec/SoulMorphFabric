package com.kdxplayz.soulmorph.command;

import com.kdxplayz.soulmorph.data.SoulData;
import com.kdxplayz.soulmorph.item.SoulShardItem;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.command.argument.GameProfileArgumentType;
import net.minecraft.text.Text;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.item.ItemStack;
import com.mojang.authlib.GameProfile;
import java.util.Collection;
import java.util.UUID;

public final class SoulCommands {
    private SoulCommands() {}
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(
            CommandManager.literal("soulmorph")
                .then(CommandManager.literal("lives").then(CommandManager.argument("player", GameProfileArgumentType.gameProfile()).executes(ctx -> {
                    Collection<GameProfile> profiles = GameProfileArgumentType.getProfileArgument(ctx, "player");
                    GameProfile target = profiles.iterator().next();
                    int lives = SoulData.get(ctx.getSource().getServer()).getLives(target.getId());
                    ctx.getSource().sendFeedback(() -> Text.literal(target.getName() + " has " + lives + "/3 lives."), false);
                    return lives;
                })))
                .then(CommandManager.literal("revive").then(CommandManager.argument("player", GameProfileArgumentType.gameProfile()).requires(src -> src.hasPermissionLevel(2)).executes(ctx -> {
                    ServerCommandSource src = ctx.getSource();
                    GameProfile target = GameProfileArgumentType.getProfileArgument(ctx, "player").iterator().next();
                    ServerPlayerEntity helper = src.getPlayer();
                    if (helper == null) { src.sendError(Text.literal("A player must hold the Soul Shards to revive someone.")); return 0; }
                    int count = countShards(helper, target.getId());
                    if (count < 3) { src.sendError(Text.literal("You need 3 of " + target.getName() + "'s Soul Shards. You have " + count + ".")); return 0; }
                    removeShards(helper, target.getId(), 3);
                    boolean ok = SoulData.get(src.getServer()).revive(src.getServer(), target);
                    if (!ok) { src.sendError(Text.literal("That player is not banned by Soul Morph.")); return 0; }
                    src.sendFeedback(() -> Text.literal(target.getName() + " has been revived with 3 lives!"), true);
                    return 1;
                })))
                .then(CommandManager.literal("setlives").requires(src -> src.hasPermissionLevel(2)).then(CommandManager.argument("player", GameProfileArgumentType.gameProfile()).then(CommandManager.argument("amount", com.mojang.brigadier.arguments.IntegerArgumentType.integer(0,3)).executes(ctx -> {
                    GameProfile target = GameProfileArgumentType.getProfileArgument(ctx, "player").iterator().next();
                    int amount = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(ctx, "amount");
                    SoulData.get(ctx.getSource().getServer()).setLives(target.getId(), amount);
                    ctx.getSource().sendFeedback(() -> Text.literal("Set " + target.getName() + " to " + amount + " lives."), true);
                    return 1;
                }))))
        ));
    }
    private static int countShards(ServerPlayerEntity player, UUID owner) {
        int count=0; for (ItemStack stack : player.getInventory().main) if (SoulShardItem.belongsTo(stack, owner)) count += stack.getCount(); return count;
    }
    private static void removeShards(ServerPlayerEntity player, UUID owner, int needed) {
        for (ItemStack stack : player.getInventory().main) if (needed > 0 && SoulShardItem.belongsTo(stack, owner)) { int take=Math.min(needed, stack.getCount()); stack.decrement(take); needed-=take; }
    }
}
