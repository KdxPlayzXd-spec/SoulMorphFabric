package com.kdxplayz.soulmorph.data;

import com.kdxplayz.soulmorph.SoulMorphMod;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.PlayerManager;
import net.minecraft.world.PersistentState;
import com.mojang.authlib.GameProfile;
import net.minecraft.server.BannedPlayerEntry;
import java.util.*;

public class SoulData extends PersistentState {
    private static final String KEY = "soulmorph_data";
    private final Map<UUID, Integer> lives = new HashMap<>();
    private final Map<UUID, Set<String>> mobSouls = new HashMap<>();
    private final Set<UUID> banned = new HashSet<>();
    private final Map<UUID, String> activeMorphs = new HashMap<>();

    public static SoulData get(MinecraftServer server) {
        return server.getOverworld().getPersistentStateManager().getOrCreate(SoulData::fromNbt, SoulData::new, KEY);
    }
    public void ensurePlayer(UUID id) { lives.putIfAbsent(id, 3); }
    public int getLives(UUID id) { return lives.getOrDefault(id, 3); }
    public int loseLife(UUID id) { int next = Math.max(0, getLives(id) - 1); lives.put(id, next); return next; }
    public void setLives(UUID id, int amount) { lives.put(id, Math.max(0, Math.min(3, amount))); }
    public void addMobSoul(UUID player, String entityId) { mobSouls.computeIfAbsent(player, k -> new LinkedHashSet<>()).add(entityId); }
    public List<String> getMobSouls(UUID player) { return new ArrayList<>(mobSouls.getOrDefault(player, Collections.emptySet())); }
    public boolean isBanned(UUID id) { return banned.contains(id); }
    public String getActiveMorph(UUID id) { return activeMorphs.getOrDefault(id, ""); }
    public void setActiveMorph(UUID id, String morph) { if (morph == null || morph.isBlank()) activeMorphs.remove(id); else activeMorphs.put(id, morph); markDirty(); }

    public void ban(GameProfile profile) {
        banned.add(profile.getId());
        MinecraftServer server = SoulMorphMod.server();
        if (server != null) server.getPlayerManager().getUserBanList().add(new BannedPlayerEntry(profile));
        markDirty();
    }
    public boolean revive(MinecraftServer server, GameProfile profile) {
        if (!banned.contains(profile.getId())) return false;
        server.getPlayerManager().getUserBanList().remove(profile);
        banned.remove(profile.getId());
        lives.put(profile.getId(), 3);
        markDirty();
        return true;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt) {
        NbtList players = new NbtList();
        for (var e : lives.entrySet()) { NbtCompound p = new NbtCompound(); p.putUuid("Id", e.getKey()); p.putInt("Lives", e.getValue()); players.add(p); }
        nbt.put("Players", players);
        NbtList souls = new NbtList();
        for (var e : mobSouls.entrySet()) { NbtCompound p = new NbtCompound(); p.putUuid("Id", e.getKey()); NbtList list = new NbtList(); e.getValue().forEach(s -> list.add(NbtString.of(s))); p.put("Souls", list); souls.add(p); }
        nbt.put("MobSouls", souls);
        NbtList bans = new NbtList(); banned.forEach(id -> bans.add(NbtString.of(id.toString()))); nbt.put("Banned", bans);
        NbtList morphs = new NbtList();
        for (var e : activeMorphs.entrySet()) { NbtCompound p = new NbtCompound(); p.putUuid("Id", e.getKey()); p.putString("Morph", e.getValue()); morphs.add(p); }
        nbt.put("ActiveMorphs", morphs);
        return nbt;
    }
    public static SoulData fromNbt(NbtCompound nbt) {
        SoulData data = new SoulData();
        NbtList players = nbt.getList("Players", 10);
        for (int i=0;i<players.size();i++) { NbtCompound p=players.getCompound(i); data.lives.put(p.getUuid("Id"), p.getInt("Lives")); }
        NbtList souls = nbt.getList("MobSouls", 10);
        for (int i=0;i<souls.size();i++) { NbtCompound p=souls.getCompound(i); Set<String> set=new LinkedHashSet<>(); NbtList list=p.getList("Souls", 8); for(int j=0;j<list.size();j++) set.add(list.getString(j)); data.mobSouls.put(p.getUuid("Id"), set); }
        NbtList bans=nbt.getList("Banned", 8); for(int i=0;i<bans.size();i++) try { data.banned.add(UUID.fromString(bans.getString(i))); } catch(IllegalArgumentException ignored) {}
        NbtList morphs = nbt.getList("ActiveMorphs", 10); for (int i=0;i<morphs.size();i++) { NbtCompound p=morphs.getCompound(i); data.activeMorphs.put(p.getUuid("Id"), p.getString("Morph")); }
        return data;
    }
}
