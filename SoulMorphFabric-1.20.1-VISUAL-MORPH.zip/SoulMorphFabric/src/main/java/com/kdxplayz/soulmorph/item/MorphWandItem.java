package com.kdxplayz.soulmorph.item;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import com.kdxplayz.soulmorph.MorphNetworking;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class MorphWandItem extends Item {
    public MorphWandItem(Settings settings) { super(settings); }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient && user instanceof net.minecraft.server.network.ServerPlayerEntity player) {
            MorphNetworking.openMenu(player);
        }
        return TypedActionResult.success(stack, world.isClient);
    }
}
