package com.kdxplayz.soulmorph.item;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import java.util.UUID;

public class SoulShardItem extends Item {
    public SoulShardItem(Settings settings) { super(settings); }
    public static ItemStack create(UUID owner, String name) {
        ItemStack stack = new ItemStack(ModItems.SOUL_SHARD);
        NbtCompound nbt = stack.getOrCreateNbt();
        nbt.putUuid("SoulOwner", owner);
        nbt.putString("SoulName", name);
        stack.setCustomName(net.minecraft.text.Text.literal(name + "'s Soul"));
        return stack;
    }
    public static boolean belongsTo(ItemStack stack, UUID owner) {
        return stack.isOf(ModItems.SOUL_SHARD) && stack.hasNbt() && stack.getNbt().containsUuid("SoulOwner") && stack.getNbt().getUuid("SoulOwner").equals(owner);
    }
}
