package com.kdxplayz.soulmorph.mixin;

import com.kdxplayz.soulmorph.client.ClientMorphs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.world.World;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Replaces the third-person player model with the captured mob's vanilla renderer.
 * The server remains authoritative for which morph is active.
 */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {
    @SuppressWarnings({"rawtypes", "unchecked"})
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void soulmorph$renderMobModel(
            LivingEntity playerEntity,
            float yaw,
            float tickDelta,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            CallbackInfo ci) {

        if (!(playerEntity instanceof PlayerEntity)) {
            return;
        }

        String morphId = ClientMorphs.get(playerEntity.getUuid());
        if (morphId.isEmpty()) {
            return;
        }

        Identifier id = Identifier.tryParse(morphId);
        if (id == null || !Registries.ENTITY_TYPE.containsId(id)) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        World world = client.world;
        if (world == null) {
            return;
        }

        EntityType<?> type = Registries.ENTITY_TYPE.get(id);
        Entity morphEntity = type.create(world);
        if (morphEntity == null) {
            return;
        }

        morphEntity.refreshPositionAndAngles(
            playerEntity.getX(),
            playerEntity.getY(),
            playerEntity.getZ(),
            playerEntity.getYaw(),
            playerEntity.getPitch()
        );
        morphEntity.setVelocity(playerEntity.getVelocity());
        morphEntity.age = playerEntity.age;

        EntityRenderer renderer =
            client.getEntityRenderDispatcher().getRenderer(morphEntity);
        renderer.render(
            morphEntity, yaw, tickDelta, matrices, vertexConsumers, light
        );
        ci.cancel();
    }
}
