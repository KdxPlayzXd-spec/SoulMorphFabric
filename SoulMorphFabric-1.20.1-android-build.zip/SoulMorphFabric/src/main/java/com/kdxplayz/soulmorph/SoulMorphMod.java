package com.kdxplayz.soulmorph;

import com.kdxplayz.soulmorph.command.SoulCommands;
import com.kdxplayz.soulmorph.data.SoulData;
import com.kdxplayz.soulmorph.item.ModItems;
import com.kdxplayz.soulmorph.item.SoulShardItem;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.PlayerDropItemCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.entity.ItemEntity;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class SoulMorphMod implements ModInitializer {
    public static final String MOD_ID = "soulmorph";
    private static MinecraftServer server;

    public static Identifier id(String path) { return new Identifier(MOD_ID, path); }
    public static MinecraftServer server() { return server; }

    @Override
    public void onInitialize() {
        ModItems.register();
        MorphNetworking.registerServer();
        PlayerDropItemCallback.EVENT.register((player, itemEntity, retainOwnership) -> itemEntity.getStack().isOf(ModItems.MORPH_WAND) ? ActionResult.FAIL : ActionResult.PASS);
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> ensureWand(newPlayer));
        ServerTickEvents.END_SERVER_TICK.register(srv -> { for (ServerPlayerEntity player : srv.getPlayerManager().getPlayerList()) { ensureWand(player); MorphNetworking.tickAbilities(player); } });
        ServerLifecycleEvents.SERVER_STARTED.register(s -> server = s);
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> server = null);

        ServerPlayConnectionEvents.JOIN.register((handler, sender, srv) -> {
            ServerPlayerEntity player = handler.getPlayer();
            SoulData data = SoulData.get(srv);
            data.ensurePlayer(player.getUuid());
            data.markDirty();
            ensureWand(player);
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((LivingEntity dead, net.minecraft.entity.damage.DamageSource source) -> {
            if (!(source.getAttacker() instanceof ServerPlayerEntity killer)) return;
            if (dead instanceof ServerPlayerEntity victim) {
                if (killer.getUuid().equals(victim.getUuid())) return;
                SoulData data = SoulData.get(killer.getServer());
                int remaining = data.loseLife(victim.getUuid());
                data.markDirty();
                ItemStack shard = SoulShardItem.create(victim.getUuid(), victim.getGameProfile().getName());
                if (!killer.getInventory().insertStack(shard)) killer.dropItem(shard, false);
                killer.sendMessage(Text.literal("You collected " + victim.getGameProfile().getName() + "'s soul. They have " + remaining + " lives left."), false);
                if (remaining <= 0) {
                    killer.sendMessage(Text.literal(victim.getGameProfile().getName() + " has lost all 3 lives and is banned."), false);
                    data.ban(victim.getGameProfile());
                    victim.networkHandler.disconnect(Text.literal("You lost all 3 souls. Your team can revive you with 3 of your Soul Shards."));
                }
            } else if (dead.getType().getRegistryEntry().registryKey().getValue() != null) {
                String mobId = Registry.ENTITY_TYPE.getId(dead.getType()).toString();
                SoulData.get(killer.getServer()).addMobSoul(killer.getUuid(), mobId);
                SoulData.get(killer.getServer()).markDirty();
                killer.sendMessage(Text.literal("Captured soul: " + mobId), true);
            }
        });

        SoulCommands.register();
    }

    public static void ensureWand(ServerPlayerEntity player) {
        boolean found = false;
        for (int i = 0; i < player.getInventory().size(); i++) {
            if (player.getInventory().getStack(i).isOf(ModItems.MORPH_WAND)) { found = true; break; }
        }
        if (!found) {
            ItemStack wand = new ItemStack(ModItems.MORPH_WAND);
            wand.setCount(1);
            if (!player.getInventory().insertStack(wand)) {
                // If the inventory is full, replace the selected slot rather than dropping the protected wand.
                player.getInventory().setStack(player.getInventory().selectedSlot, wand);
            }
        }
    }
}
