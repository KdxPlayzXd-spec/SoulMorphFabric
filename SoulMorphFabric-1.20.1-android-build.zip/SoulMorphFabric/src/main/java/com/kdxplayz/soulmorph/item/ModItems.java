package com.kdxplayz.soulmorph.item;

import com.kdxplayz.soulmorph.SoulMorphMod;
import net.minecraft.item.Item;
import net.minecraft.util.registry.Registry;

public final class ModItems {
    public static final Item MORPH_WAND = new MorphWandItem(new Item.Settings().maxCount(1));
    public static final Item SOUL_SHARD = new SoulShardItem(new Item.Settings().maxCount(64));
    private ModItems() {}
    public static void register() {
        Registry.register(Registry.ITEM, SoulMorphMod.id("morph_wand"), MORPH_WAND);
        Registry.register(Registry.ITEM, SoulMorphMod.id("soul_shard"), SOUL_SHARD);
    }
}
