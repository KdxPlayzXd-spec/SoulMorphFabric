# Soul Morph — Fabric 1.20.1

Soul Morph is a Fabric mod source project for Minecraft Java 1.20.1. It requires Java 17, Fabric Loader and Fabric API.

## Included mechanics

- Gives each joining/respawning player a Morph Wand and restores it if it is missing; manual item dropping is blocked by the existing item behavior.
- Captures a mob soul when a player kills that mob. Captured souls are stored per player and persist across server restarts.
- The wand opens a searchable captured-soul menu. Players can select a captured morph or use **Remove Morph** to clear it.
- Morph selection is validated on the server; active morph state is saved in world persistent data.
- PvP soul shards, three-life tracking, bans, revival and the `/soulmorph` commands are retained.
- Morph selection triggers a client-side soul/smoke spiral effect and a vanilla beacon activation sound.
- Ability effects now include survival flight for parrot, blaze, phantom, bat, ghast and allay; fire resistance for blaze/magma cube; water breathing and faster swimming for aquatic mobs; spider wall climbing; jump boost for rabbit/slime/goat; slow falling for flying mobs; and themed speed, strength, resistance or night vision for several other mobs.

## Important implementation limits

This update does **not** yet render a real mob model in place of the player's model. The transformation visual is a soul-and-smoke particle sequence, not a full ghost-to-mob 3D model animation. Abilities are implemented as player movement/status effects; mob-specific attack controls (for example creeper detonation, skeleton bow shots or blaze fireballs) are not implemented. Those require a dedicated ability input/network protocol and balancing. A true disguise renderer also needs a carefully tested client rendering layer and multiplayer synchronization; this project does not claim that feature is complete.

The wand inventory protection is not a comprehensive anti-cheat inventory lock. Server operators should test edge cases such as death, creative mode, inventory manipulation and reconnect behavior on a test server before using it publicly.

## Build

Use JDK 17 and Gradle 8.7. From this directory run:

```sh
gradle build --no-daemon
```

The GitHub Actions workflow in `.github/workflows/build.yml` builds with Java 17 and Gradle 8.7 and uploads the JAR as an artifact. This editing environment did not have Gradle installed, so the project has **not been compiled or runtime-tested here**. Do not treat this source ZIP as a verified release until the workflow completes successfully and the mod is tested in Minecraft.

## Compatibility

- Minecraft Java 1.20.1
- Yarn mappings 1.20.1+build.10
- Fabric Loader 0.15.11
- Fabric API 0.92.2+1.20.1
- Java 17
