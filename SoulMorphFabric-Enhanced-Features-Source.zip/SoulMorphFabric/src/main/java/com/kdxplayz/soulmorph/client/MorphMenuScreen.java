package com.kdxplayz.soulmorph.client;

import com.kdxplayz.soulmorph.MorphNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public class MorphMenuScreen extends Screen {
    private final List<String> souls;
    private final String active;
    private int scroll;
    private boolean showData;
    private TextFieldWidget searchBox;
    private List<ButtonWidget> mobButtons = new ArrayList<>();

    public MorphMenuScreen(List<String> souls, String active) {
        super(Text.literal("Soul Morph"));
        this.souls = new ArrayList<>(souls);
        this.active = active;
    }

    @Override
    protected void init() {
        searchBox = new TextFieldWidget(textRenderer, width / 2 - 105, 34, 210, 22,
                Text.literal("Search mobs"));
        searchBox.setMaxLength(64);
        searchBox.setChangedListener(value -> {
            scroll = 0;
            rebuildMobButtons();
        });
        addDrawableChild(searchBox);

        addDrawableChild(ButtonWidget.builder(Text.literal(showData ? "Hide Data" : "Show Data"), b -> {
            showData = !showData;
            b.setMessage(Text.literal(showData ? "Hide Data" : "Show Data"));
            rebuildMobButtons();
        }).dimensions(width / 2 - 105, height - 54, 100, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("?"), b ->
                client.setScreen(new MorphHelpScreen(this)))
                .dimensions(width / 2 + 5, height - 54, 25, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Remove Morph"), b -> choose("none"))
                .dimensions(width / 2 - 105, height - 80, 100, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(width / 2 + 5, height - 80, 100, 20).build());

        rebuildMobButtons();
    }

    private List<String> filteredSouls() {
        String query = searchBox == null ? "" : searchBox.getText().toLowerCase(Locale.ROOT).trim();
        return souls.stream().filter(id -> id.toLowerCase(Locale.ROOT).contains(query))
                .collect(Collectors.toList());
    }

    private void rebuildMobButtons() {
        for (ButtonWidget button : mobButtons) remove(button);
        mobButtons.clear();
        if (searchBox == null) return;

        List<String> filtered = filteredSouls();
        int columns = 3;
        int cellWidth = 94;
        int gap = 5;
        int totalWidth = columns * cellWidth + (columns - 1) * gap;
        int left = width / 2 - totalWidth / 2;
        int top = 68;
        int rowHeight = showData ? 39 : 27;
        int rowsVisible = Math.max(1, (height - 160) / rowHeight);
        int pageSize = columns * rowsVisible;
        int start = Math.min(scroll * pageSize, Math.max(0, filtered.size() - 1));
        int end = Math.min(filtered.size(), start + pageSize);

        for (int i = start; i < end; i++) {
            final String id = filtered.get(i);
            int local = i - start;
            int x = left + (local % columns) * (cellWidth + gap);
            int y = top + (local / columns) * rowHeight;
            String name = id.substring(id.indexOf(':') + 1).replace('_', ' ');
            name = name.substring(0, 1).toUpperCase(Locale.ROOT) + name.substring(1);
            if (id.equals(active)) name = "✓ " + name;
            String label = showData ? name + "\n" + id : name;
            ButtonWidget button = ButtonWidget.builder(Text.literal(label), b -> choose(id))
                    .dimensions(x, y, cellWidth, showData ? 34 : 22).build();
            mobButtons.add(addDrawableChild(button));
        }

        if (filtered.isEmpty()) {
            // Empty-state text is drawn in render().
        }
        if (filtered.size() > pageSize) {
            mobButtons.add(addDrawableChild(ButtonWidget.builder(Text.literal("▲"), b -> {
                scroll = Math.max(0, scroll - 1); rebuildMobButtons();
            }).dimensions(width / 2 + totalWidth / 2 + 5, top, 20, 20).build()));
            mobButtons.add(addDrawableChild(ButtonWidget.builder(Text.literal("▼"), b -> {
                scroll = Math.min((filtered.size() - 1) / pageSize, scroll + 1); rebuildMobButtons();
            }).dimensions(width / 2 + totalWidth / 2 + 5, top + 25, 20, 20).build()));
        }
    }

    private void choose(String id) {
        var buf = net.fabricmc.fabric.api.networking.v1.PacketByteBufs.create();
        buf.writeString(id);
        ClientPlayNetworking.send(MorphNetworking.SELECT_MORPH, buf);
        close();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        context.fill(0, 0, width, height, 0x99000000);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("SOUL MORPH"), width / 2, 12, 0xB98CFF);
        context.drawTextWithShadow(textRenderer,
                Text.literal("Captured souls: " + souls.size()), width / 2 - 105, 59, 0xB8C8E8);
        if (filteredSouls().isEmpty()) {
            context.drawCenteredTextWithShadow(textRenderer,
                    Text.literal(souls.isEmpty() ? "No captured souls yet!" : "No matching souls found."),
                    width / 2, height / 2 - 8, 0xFFFFFF);
        }
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() { return false; }

    private static class MorphHelpScreen extends Screen {
        private final Screen parent;
        MorphHelpScreen(Screen parent) {
            super(Text.literal("Soul Morph Help"));
            this.parent = parent;
        }
        @Override protected void init() {
            addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> client.setScreen(parent))
                    .dimensions(width / 2 - 50, height - 35, 100, 20).build());
        }
        @Override public void render(DrawContext context, int mouseX, int mouseY, float delta) {
            renderBackground(context);
            context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 25, 0xB98CFF);
            context.drawCenteredTextWithShadow(textRenderer, "Search for a captured mob, then select it to morph.", width / 2, 65, 0xFFFFFF);
            context.drawCenteredTextWithShadow(textRenderer, "Show Data displays each mob's registry ID.", width / 2, 82, 0xB8C8E8);
            context.drawCenteredTextWithShadow(textRenderer, "Use Remove Morph in-game to return to normal.", width / 2, 99, 0xB8C8E8);
            super.render(context, mouseX, mouseY, delta);
        }
        @Override public boolean shouldPause() { return false; }
    }
}
