package com.kdxplayz.soulmorph.client;

import com.kdxplayz.soulmorph.MorphNetworking;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;

public class SoulMorphClient implements ClientModInitializer {
    private static int transformationTicks = 0;
    @Override public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(MorphNetworking.MORPH_LIST, (client, handler, buf, responseSender) -> {
            var souls = buf.readCollection(ArrayList::new, b -> b.readString(128));
            String active = buf.readString(128);
            client.execute(() -> MinecraftClient.getInstance().setScreen(new MorphMenuScreen(souls, active)));
        });
        ClientPlayNetworking.registerGlobalReceiver(MorphNetworking.MORPH_EFFECT, (client, handler, buf, responseSender) -> {
            buf.readString(128);
            client.execute(() -> transformationTicks = 40);
        });
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (transformationTicks > 0 && client.player != null && client.world != null) {
                transformationTicks--;
                var p = client.player;
                double radius = 0.35 + (40 - transformationTicks) * 0.018;
                for (int i = 0; i < 5; i++) {
                    double angle = (transformationTicks * 0.35) + (Math.PI * 2 * i / 5.0);
                    double x = p.getX() + Math.cos(angle) * radius;
                    double z = p.getZ() + Math.sin(angle) * radius;
                    client.world.addParticle(ParticleTypes.SOUL, x, p.getY() + 0.2 + (40 - transformationTicks) * 0.035, z, 0, 0.025, 0);
                    if (i % 2 == 0) client.world.addParticle(ParticleTypes.SMOKE, x, p.getY() + 0.6, z, 0, 0.025, 0);
                }
            }
        });
    }
}
