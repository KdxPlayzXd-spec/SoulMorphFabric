# Soul Morph — Fabric 1.20.1

A Fabric mod starter project for Minecraft 1.20.1. Requires Java 17, Fabric Loader and Fabric API. It is designed to run on both an integrated world and a dedicated Fabric server. JEI and AppleSkin are optional client-side mods; this project does not add recipes or food mechanics that require either integration.

## Current implementation

- Automatically provisions a Morph Wand when a player joins or respawns. The server checks for a wand every tick and restores one if missing; the manual item-drop callback blocks dropping the wand.
- Right-clicking the wand opens a client-side captured-soul menu. Selection is sent to the server and validated against that player's captured soul list.
- Active morph selection is saved in overworld `PersistentState` and survives server restarts.
- Morph ability effects currently implemented: blaze (fire resistance), dolphin (water breathing and dolphin's grace), rabbit/slime/magma cube (jump boost), spider/cave spider (night vision), enderman (speed), zombie/husk/drowned (strength), phantom (slow falling), and turtle (resistance).
- Morph activation plays a vanilla beacon sound and emits soul particles.
- Existing three-life PvP, ban, soul shard and revival code is retained.

## Important limitations

This is an **in-progress source project**, not a verified release build. The current version implements morph selection and mob-themed ability effects, but it does **not yet replace the player's rendered model/skin with the actual mob model**. It also does not yet include bespoke sound files, a full animation system, a configuration file/Mod Menu integration, or a comprehensive inventory-click/death-drop mixin. The wand is restored if missing and manual dropping is blocked, but exhaustive protection against every possible inventory manipulation still needs testing.

The GUI is a lightweight vanilla screen, not a custom animated container. All morph state and selection validation are server-authoritative; the client screen only displays the server-provided list and sends the selected entity ID.

## Build

Install JDK 17 and Gradle 8.x, then run from this directory:

```bash
gradle build
```

The resulting mod jar should appear under `build/libs/`. This environment did not have Gradle installed, so this source update has not been compiled or tested here. Resolve any mapping/API compile differences against Fabric API 0.92.2+1.20.1 before distributing it.

## Compatibility

- Minecraft 1.20.1
- Fabric Loader 0.15.x or compatible
- Fabric API 0.92.2+1.20.1
- Java 17
- JEI / AppleSkin: optional client-side companions; no direct integration is required for the wand or morph networking.
