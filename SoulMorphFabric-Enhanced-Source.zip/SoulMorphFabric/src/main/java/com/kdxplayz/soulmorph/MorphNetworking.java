
package com.kdxplayz.soulmorph;

import com.kdxplayz.soulmorph.data.SoulData;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.registry.Registries;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;

import java.util.List;

public final class MorphNetworking {

    public static final Identifier OPEN_MENU =
        SoulMorphMod.id("open_morph_menu");

    public static final Identifier SELECT_MORPH =
        SoulMorphMod.id("select_morph");

    public static final Identifier MORPH_LIST =
        SoulMorphMod.id("morph_list");

    private MorphNetworking() {}

    public static void registerServer() {
        ServerPlayNetworking.registerGlobalReceiver(
            SELECT_MORPH,
            (server, player, handler, buf, responseSender) -> {
                String requested = buf.readString(128);
                server.execute(() -> select(player, requested));
            }
        );
    }

    public static void openMenu(ServerPlayerEntity player) {
        List<String> souls =
            SoulData.get(player.getServer()).getMobSouls(player.getUuid());

        PacketByteBuf buf = PacketByteBufs.create();

        buf.writeCollection(souls, PacketByteBuf::writeString);

        buf.writeString(
            SoulData.get(player.getServer()).getActiveMorph(player.getUuid())
        );

        ServerPlayNetworking.send(player, MORPH_LIST, buf);
    }

    private static void select(ServerPlayerEntity player, String requested) {
        SoulData data = SoulData.get(player.getServer());

        if (requested.equals("none")) {
            data.setActiveMorph(player.getUuid(), "");
            player.sendMessage(Text.literal("Morph cleared."), true);
            return;
        }

        if (!data.getMobSouls(player.getUuid()).contains(requested)) {
            player.sendMessage(
                Text.literal("You have not captured that soul."),
                false
            );
            return;
        }

        Identifier entityId = Identifier.tryParse(requested);

        if (entityId == null ||
            !Registries.ENTITY_TYPE.containsId(entityId)) {
            player.sendMessage(
                Text.literal("That entity cannot be used as a morph."),
                false
            );
            return;
        }

        data.setActiveMorph(player.getUuid(), requested);

        player.getWorld().playSound(
            null,
            player.getBlockPos(),
            SoundEvents.BLOCK_BEACON_ACTIVATE,
            SoundCategory.PLAYERS,
            0.8f,
            1.35f
        );

            player.getServerWorld().spawnParticles(
            ParticleTypes.SOUL,
            player.getX(), player.getY() + 1, player.getZ(),
            24, .45, .8, .45, .03
        );

        player.sendMessage(
            Text.literal("Morphed into " + requested + "."),
            true
        );
    }

    public static void tickAbilities(ServerPlayerEntity player) {
        String id = SoulData.get(player.getServer())
            .getActiveMorph(player.getUuid());

        if (id.isEmpty()) return;

        switch (id) {
            case "minecraft:blaze" ->
                player.addStatusEffect(new StatusEffectInstance(
                    StatusEffects.FIRE_RESISTANCE, 45, 0, true, false
                ));

            case "minecraft:dolphin" -> {
                player.addStatusEffect(new StatusEffectInstance(
                    StatusEffects.WATER_BREATHING, 45, 0, true, false
                ));
                player.addStatusEffect(new StatusEffectInstance(
                    StatusEffects.DOLPHINS_GRACE, 45, 0, true, false
                ));
            }

            case "minecraft:rabbit", "minecraft:slime",
                 "minecraft:magma_cube" ->
                player.addStatusEffect(new StatusEffectInstance(
                    StatusEffects.JUMP_BOOST, 45, 1, true, false
                ));

            case "minecraft:spider", "minecraft:cave_spider" ->
                player.addStatusEffect(new StatusEffectInstance(
                    StatusEffects.NIGHT_VISION, 45, 0, true, false
                ));

            case "minecraft:enderman" ->
                player.addStatusEffect(new StatusEffectInstance(
                    StatusEffects.SPEED, 45, 1, true, false
                ));

            case "minecraft:zombie", "minecraft:husk",
                 "minecraft:drowned" ->
                player.addStatusEffect(new StatusEffectInstance(
                    StatusEffects.STRENGTH, 45, 0, true, false
                ));

            case "minecraft:phantom" ->
                player.addStatusEffect(new StatusEffectInstance(
                    StatusEffects.SLOW_FALLING, 45, 0, true, false
                ));

            case "minecraft:turtle" ->
                player.addStatusEffect(new StatusEffectInstance(
                    StatusEffects.RESISTANCE, 45, 0, true, false
                ));

            default -> { }
        }
    }
}
